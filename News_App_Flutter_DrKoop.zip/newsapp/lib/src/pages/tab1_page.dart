import 'package:flutter/material.dart';
import 'package:newsapp/src/widgets/lista_noticias.dart';
import 'package:provider/provider.dart';
import 'package:newsapp/src/services/news_service.dart';


class Tab1Page extends StatefulWidget {

  @override
  State<Tab1Page> createState() => _Tab1PageState();
}

/* Mantener el encabezando, despues del scroll, o cnavegacion del page */
//Rcordando el estado

class _Tab1PageState extends State<Tab1Page> with AutomaticKeepAliveClientMixin{
  @override
  Widget build(BuildContext context) {

    final headlines = Provider.of<NewsService>(context).headlines;
    //ListaNoticias( headlines )
    return Scaffold(
      /* SPINNER BEFORE LOADING API */
      body: ( headlines.length == 0)
      ? Center(
        child: CircularProgressIndicator(),
      )
      : ListaNoticias( headlines )
   );
  }
  
  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}