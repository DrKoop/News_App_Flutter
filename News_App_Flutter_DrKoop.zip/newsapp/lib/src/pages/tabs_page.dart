import 'package:flutter/material.dart';
import 'package:newsapp/src/pages/tab1_page.dart';
import 'package:newsapp/src/pages/tab2_page.dart';
import 'package:provider/provider.dart';

class TabsPage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => new _NavegacionModel(), //Cconectado mi provider para que se pueda comunicar con cualquier widget dentro del proyecto 
      child: Scaffold(
        body: _Paginas(),
        bottomNavigationBar: _Navegacion(),
       ),
    );
  }
}






class _Navegacion extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    
  //Conectando con nuestro Provider... Accediendo a las propiedas de mi clase..
    final navegacionModel = Provider.of<_NavegacionModel>(context);

    return BottomNavigationBar(
      currentIndex: navegacionModel.paginaActual,
      onTap: (i) => navegacionModel.paginaActual = i,
      items: [
        BottomNavigationBarItem( icon:Icon( Icons.person_outline), label : 'Para ti'),
        BottomNavigationBarItem( icon:Icon( Icons.public), label : 'Encabezados'),
      ]
      );
  }
}






class _Paginas extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    //Volviendo dinamico Pageview
    final navegacionModel = Provider.of<_NavegacionModel>(context);
    //final newsService = Provider.of<NewsService>(context);

    return PageView(
      controller: navegacionModel.pageController,
      physics: NeverScrollableScrollPhysics(),
      children: <Widget> [
        Tab1Page(),
        Tab2Page()
      ],
    );
  }
}


/* -------------------------------------------------------------------------- */
/*                                  PROVIDER                                  */
/* -------------------------------------------------------------------------- */
class _NavegacionModel with ChangeNotifier{

  int _paginaActual = 0;

  //Volviendo dinamico el pageview
  PageController _pageController = new PageController( initialPage: 1);

  //Se instancias de esta forma para que pueda ser global dicha propiedad, cada que se llame a esta clase 
  int get paginaActual => this._paginaActual;
  //set + guardra informacion en el dispositivo en fisico
  set paginaActual( int valor){
    this._paginaActual = valor;
    //Volviendo dinamico el pageview
    _pageController.animateToPage(valor, duration: Duration(milliseconds:450), curve: Curves.easeOut );
    notifyListeners();
  }

  PageController get pageController => this._pageController;
}