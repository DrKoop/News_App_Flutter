/* Archivo encargado de realizar las peticiones https */

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:newsapp/src/models/category.dart';
import 'package:newsapp/src/models/news_models.dart';
//consumiendo api , consumiendo peticiones htttp
import 'package:http/http.dart' as http;

final _URL_ = 'https://newsapi.org/v2';
final _apikey = 'f6527a607c4e4d7cbaf1516785f6804f';


class NewsService with ChangeNotifier{
   
   List<Article> headlines = [];

   /* identificar la categoria seleccionada */
   String _selectedCategory ='business';

  List<Category> categorias  = [
    Category(FontAwesomeIcons.building, 'business' ),
    Category(FontAwesomeIcons.tv, 'entertainment' ),
    Category(FontAwesomeIcons.addressCard, 'general' ),
    Category(FontAwesomeIcons.headSideVirus, 'health' ),
    Category(FontAwesomeIcons.vials, 'science' ),
    Category(FontAwesomeIcons.volleyballBall, 'sports' ),
    Category(FontAwesomeIcons.memory, 'technology' ),
  ];    

/* identificar la categoria seleccionada */
Map<String, List<Article >> categoryArticles = {};



  NewsService(){
    this.getTopHeadlines();
    //iniciando cada valor de cada articulo
    categorias.forEach((item){
      this.categoryArticles[item.name] = new List.empty();
    });
  }


/* identificar la categoria seleccionada */

 get selectedCategory => this._selectedCategory;
 set selectedCategory( String valor){
 this._selectedCategory = valor;
 this.getArticlesByCategory( valor );
  notifyListeners();
}

//Devolver categoria al seleccionar
List<Article> get getArticuloSeleccionado =>  this.categoryArticles[this.selectedCategory];


  //http.get(Uri.parse(someString))

  //consumiendo API
   getTopHeadlines() async {
    final url = Uri.parse('$_URL_/top-headlines?country=us&apiKey=$_apikey');
    final resp = await http.get(url);
    final newsResponse = newsResponseFromJson(resp.body);
    //consumiendo todos los encabezados de todos los articulos
    this.headlines.addAll( newsResponse.articles );

    //guardando cambios en el dispositivos
    notifyListeners();
   }


/* identificar la categoria seleccionada */
  getArticlesByCategory( String category) async{

    if( this.categoryArticles[category].length > 0){
      return  this.categoryArticles[category];
    }

    final url = Uri.parse('$_URL_/top-headlines?country=us&apiKey=$_apikey&category=s$category');
    final resp = await http.get(url);
    final newsResponse = newsResponseFromJson(resp.body);
    this.categoryArticles[category].addAll( newsResponse.articles);

    //guardando cambios en el dispositivos
    notifyListeners();
  }
}